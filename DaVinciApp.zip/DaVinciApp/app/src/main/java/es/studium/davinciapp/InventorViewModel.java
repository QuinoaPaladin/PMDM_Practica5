package es.studium.davinciapp;

import androidx.lifecycle.ViewModel;

public class InventorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}