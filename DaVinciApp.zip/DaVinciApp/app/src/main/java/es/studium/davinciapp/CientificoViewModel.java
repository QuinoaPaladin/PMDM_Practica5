package es.studium.davinciapp;

import androidx.lifecycle.ViewModel;

public class CientificoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}