package es.studium.davinciapp;

import androidx.lifecycle.ViewModel;

public class PintorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}