package es.studium.davinciapp;

import androidx.lifecycle.ViewModel;

public class EscultorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}